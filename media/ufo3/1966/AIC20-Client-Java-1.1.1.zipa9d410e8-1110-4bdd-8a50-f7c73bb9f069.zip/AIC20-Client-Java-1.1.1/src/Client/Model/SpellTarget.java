package Client.Model;

public enum SpellTarget {
    SELF, ALLIED, ENEMY
}
