1. Download the latest version of the server and client.
To run the server:
2. Open terminal/cmd. Move to the folder of the server. Run the .jar file:
	java -jar <filename>.jar
3. Choose map to work with
To run clients:
4. Run main function in "controller.py" as the number of players in a game(4 times). Obviously you can run different clients.
