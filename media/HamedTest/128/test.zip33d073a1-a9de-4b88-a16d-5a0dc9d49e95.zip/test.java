import java.util.Scanner;

public class PhysicsLaboratory {

    public static final String PRINT_STREAM = "%.3f %.3f";

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int numberOfPoints = scanner.nextInt();
        float[] x = new float[numberOfPoints];
        float[] y = new float[numberOfPoints];

        for (int i = 0; i < numberOfPoints; i++) {
            x[i] = scanner.nextFloat();
            y[i] = scanner.nextFloat();
        }

        float slope = getSlope(x, y);
        float intercept = getIntercept(x, y, slope);

        System.out.printf(PRINT_STREAM, slope, intercept);
    }

    private static float getIntercept(float[] x, float[] y, float slope) {
        float intercept;
        intercept = getAverage(y) - slope * getAverage(x);
        return intercept;
    }

    private static float getSlope(float[] x, float[] y) {
        float xBar = getAverage(x);
        float yBar = getAverage(y);
        float numerator = 0, denominator = 0, slope;

        for (int i = 0; i < x.length; i++) {
            numerator += (x[i] - xBar) * (y[i] - yBar);
            denominator += (x[i] - xBar) * (x[i] - xBar);
        }

        slope = numerator / denominator;
        return slope;
    }

    private static float getAverage(float[] elements) {
        float sumOfElements = 0, average;

        for (int i = 0; i < elements.length; i++) {
            sumOfElements += elements[i];
        }

        average = sumOfElements / elements.length;
        return average;
    }
}