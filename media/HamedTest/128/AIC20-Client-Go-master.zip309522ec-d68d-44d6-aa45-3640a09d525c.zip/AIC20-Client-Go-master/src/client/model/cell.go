package model

type Cell struct {
	Row int `json:"row"`
	Col int `json:"col"`
}
