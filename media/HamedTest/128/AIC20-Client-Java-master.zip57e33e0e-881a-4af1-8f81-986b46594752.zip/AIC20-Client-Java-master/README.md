# AI Challenge 2019 Java Client
## Setup instructions

It is recommended to use IntelliJ IDEA(JetBrains):

```
1. Download the latest version of the server and client.
To run the server:
2. Open terminal/cmd. Move to the folder of the server. Run the .jar file:
	java -jar <filename>.jar
To run clients:
3. Import directory you want to save and run the code. You must import Gson library.
4. Run main function in Main.java as the number of players in a game(4 times). Obviously you can run different clients.
```





