package Client.Model;

/**
 * This class has types of targets.
 * Please do not change this class, it is a piece of the internal implementation
 * and you do not need to know anything about this class.
 */

public enum TargetType {
    SELF, ENEMY, ALLIED
}
