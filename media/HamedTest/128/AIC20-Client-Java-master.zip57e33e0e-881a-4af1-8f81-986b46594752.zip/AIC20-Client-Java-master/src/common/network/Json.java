package common.network;

import com.google.gson.Gson;

/**
 * Json utilities.
 */
public class Json {

    public static final Gson GSON = new Gson();

}