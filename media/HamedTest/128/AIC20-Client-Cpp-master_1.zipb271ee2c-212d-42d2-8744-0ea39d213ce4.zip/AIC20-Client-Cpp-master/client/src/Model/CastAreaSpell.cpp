#include "CastAreaSpell.h"

int CastAreaSpell::getRemainingTurns() const {
    return remaining_turns_;
}
